<p align="right"> چند راه برای نصب برنامه هست  </p>
<p align="right">  یکی از راه هایی که اول توصیه میکنم نصب از طریق پکیج هست  </p>
<p align="left"> python setup.py sdist </p>
<p align="right">بعد از ساختن پکیچ به سادگی از دستور پایپ اینستال پکیج رو نصب میکنید  </p>
<p align="right">  برای لینوکسی ها با دستور زیر پیشنیازها رو نصب کنید و برنامه رو از ترمینال اجرا کنید </p>
<p >python3.7 -m pip install -U -r requirementsLinux.txt </p>
<p>python3.7 SubToDlRun.py<br>
<p align="right">  برای ویندوز با دستور زیر پیشنیازها رو نصب کنید و برنامه رو از ترمینال اجرا کنید </p>
<p >python3.7 -m pip install -U -r requirementsWindows.txt </p>
<p>python3.7 SubToDlRun.py<br>
<p align="right" > یامیتونید فایل اجرایی باتوجه به سیستمی که نصب دارید بسازید مراحل برای ویندوز و بقیه ی سیستم عامل ها مشابه هست  </p>
<p align="right">خب مراحل زیر رو انجام بدید <p>
<ol>
  <li>install pyinstaller using pip install </li>
  <li>open your cmd /terminal </li>
  <li>copy/paste this : pyinstaller --onefile --windowed --icon=index.ico SubToDlRun.py</li>
</ol> 
<p align="right" > توجه کنید که برای ساختن فایل اجرایی حتما پیش نیاز هارو نصب کرده باشید  </p>
